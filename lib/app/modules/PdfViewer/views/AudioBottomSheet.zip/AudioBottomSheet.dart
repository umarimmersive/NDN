import 'package:audio_manager/audio_manager.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/pdf_viewer_controller.dart';

class AudioBottomSheet extends StatelessWidget {
  final audioController = Get.find<PdfViewer1Controller>();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
            topRight: Radius.circular(40.0),
            bottomRight: Radius.circular(00.0),
            topLeft: Radius.circular(40.0),
            bottomLeft: Radius.circular(00.0)),
      ),
      height: 1000,
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          Expanded(
            child: ListView.builder(
              shrinkWrap: true,
              physics: BouncingScrollPhysics(),
              itemCount: audioController.audioList.length,
              itemBuilder: (BuildContext context, int index) {
                return Padding(
                  padding: const EdgeInsets.only(top: 10.0),
                  child: ListTile(
                    title: Text(audioController.audioList[index]),
                    onTap: () {
                      audioController.playAudio(audioController.audioList[index]);
                    },
                  ),
                );
              },
            ),
          ),
          Obx(() {
            if (audioController.currentTrack.value != null) {
              return Column(children: <Widget>[
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: songProgress(context),
                ),
                Container(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      IconButton(
                          icon: getPlayModeIcon(audioController.playMode),
                          onPressed: () {
                            audioController.playMode = AudioManager.instance.nextMode();
                          }),
                      IconButton(
                          iconSize: 36,
                          icon: Icon(
                            Icons.skip_previous,
                            color: Colors.black,
                          ),
                          onPressed: () => AudioManager.instance.previous()),
                      IconButton(
                        onPressed: () async {
                          bool playing = await AudioManager.instance.playOrPause();
                          print("await -- $playing");
                        },
                        padding: const EdgeInsets.all(0.0),
                        icon: Icon(
                          audioController.isPlaying.value ? Icons.pause : Icons.play_arrow,
                          size: 48.0,
                          color: Colors.black,
                        ),
                      ),
                      IconButton(
                          iconSize: 36,
                          icon: Icon(
                            Icons.skip_next,
                            color: Colors.black,
                          ),
                          onPressed: () => AudioManager.instance.next()),
                      IconButton(
                          icon: Icon(
                            Icons.stop,
                            color: Colors.black,
                          ),
                          onPressed: () => AudioManager.instance.stop()),
                    ],
                  ),
                ),
              ]);
            } else {
              return Container();
            }
          }),
        ],
      ),
    );
  }

  Widget getPlayModeIcon(PlayMode playMode) {
    switch (playMode) {
      case PlayMode.sequence:
        return Icon(
          Icons.repeat,
          color: Colors.black,
        );
      case PlayMode.shuffle:
        return Icon(
          Icons.shuffle,
          color: Colors.black,
        );
      case PlayMode.single:
        return Icon(
          Icons.repeat_one,
          color: Colors.black,
        );
    }
    return Container();
  }

  Widget songProgress(BuildContext context) {
    var style = TextStyle(color: Colors.black);
    return Row(
      children: <Widget>[
       /* Text(
          _formatDuration(audioController.position!),
          style: style,
        ),*/
        Expanded(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 5),
            child: SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  trackHeight: 2,
                  thumbColor: Colors.blueAccent,
                  overlayColor: Colors.blue,
                  thumbShape: RoundSliderThumbShape(
                    disabledThumbRadius: 5,
                    enabledThumbRadius: 5,
                  ),
                  overlayShape: RoundSliderOverlayShape(
                    overlayRadius: 10,
                  ),
                  activeTrackColor: Colors.blueAccent,
                  inactiveTrackColor: Colors.grey,
                ),
                child: Slider(
                  value: audioController.slider.value ?? 0,
                  onChanged: (value) {

                    audioController.slider.value = value;

                  },
                  onChangeEnd: (value) {
                    if (audioController!.duration != null) {
                      Duration msec = Duration(
                          milliseconds:
                          (audioController.duration!.inMilliseconds * value).round());
                      AudioManager.instance.seekTo(msec);
                    }
                  },
                )),
          ),
        ),
       /* Text(
          _formatDuration(audioController.duration!),
          style: style,
        ),*/
      ],
    );
  }

  String _formatDuration(Duration d) {
    if (d == null) return "--:--";
    int minute = d.inMinutes;
    int second = (d.inSeconds > 60) ? (d.inSeconds % 60) : d.inSeconds;
    String format = ((minute < 10) ? "0$minute" : "$minute") +
        ":" +
        ((second < 10) ? "0$second" : "$second");
    return format;
  }

  Widget volumeFrame() {
    return Row(children: <Widget>[
      IconButton(
          padding: EdgeInsets.all(0),
          icon: Icon(
            Icons.audiotrack,
            color: Colors.black,
          ),
          onPressed: () {
            AudioManager.instance.setVolume(0);
          }),
      Expanded(
          child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 0),
              child: Slider(
                value: audioController.sliderVolume.value ?? 0,
                onChanged: (value) {
                   audioController.sliderVolume.value = value;
                    AudioManager.instance.setVolume(value, showVolume: true);
                },
              )))
    ]);
  }


}
