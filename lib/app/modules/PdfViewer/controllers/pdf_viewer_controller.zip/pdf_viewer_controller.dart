import 'dart:io';

import 'package:audio_manager/audio_manager.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';

class PdfViewer1Controller extends GetxController {
  //TODO: Implement PdfViewerController

  final count = 0.obs;
  final pdf_url = ''.obs;
  final bookId = ''.obs;
  final title = ''.obs;
  @override
  void onInit() {

    pdf_url.value=Get.parameters['pdf_url'].toString();
    bookId.value=Get.parameters['bookId'].toString();
    title.value=Get.parameters['title'].toString();
    initPlatformState();
    setupAudio();
    loadFile();
    print('pdf_url-----------$pdf_url');
    super.onInit();
  }

  @override
  void dispose() {
    AudioManager.instance.release();
    // TODO: implement dispose
    super.dispose();
  }


  final platformVersion = 'Unknown'.obs;
  final isPlaying = false.obs;
  late Duration duration;
  late Duration position;
  final slider=0.0.obs;
  final sliderVolume=0.0.obs;
  final error=''.obs;
  final curIndex = 0.obs;
  PlayMode playMode = AudioManager.instance.playMode;

  final list = [
   /* {
      "title": "Assets",
      "desc": "assets playback",
      "url": "assets/xv.mp3",
      "coverUrl": "assets/ic_launcher.png"
    },*/
    {
      "title": "network",
      "desc": "network resouce playback",
      "url": "https://dl.espressif.com/dl/audio/ff-16b-2c-44100hz.m4a",
      "coverUrl": "https://homepages.cae.wisc.edu/~ece533/images/airplane.png"
    }
  ];


  final audioList = [
    'Audio 1',
    'Audio 2',
    'Audio 3',
    'Audio 4','Audio 1',
    'Audio 2',
    'Audio 3',
    'Audio 4',
  ];

  var currentTrack = ''.obs;

  void playAudio(String track) {
    currentTrack.value = track;
  }


  void setupAudio() {
    List<AudioInfo> _list = [];
    list.forEach((item) => _list.add(AudioInfo(item["url"]!,
        title: item["title"]!, desc: item["desc"]!, coverUrl: item["coverUrl"]!)));

    AudioManager.instance.audioList = _list;
    AudioManager.instance.intercepter = true;
    AudioManager.instance.play(auto: false);

    AudioManager.instance.onEvents((events, args) {
      print("$events, $args");
      switch (events) {
        case AudioManagerEvents.start:
          print(
              "start load data callback, curIndex is ${AudioManager.instance.curIndex}");
          position = AudioManager.instance.position;
          duration = AudioManager.instance.duration;
          slider.value = 0;
          update();
          AudioManager.instance.updateLrc("audio resource loading....");
          break;
        case AudioManagerEvents.ready:
          print("ready to play");
          error.value  = 'null';
          sliderVolume.value  = AudioManager.instance.volume;
          position = AudioManager.instance.position;
          duration = AudioManager.instance.duration;
          update();
          // if you need to seek times, must after AudioManagerEvents.ready event invoked
          // AudioManager.instance.seekTo(Duration(seconds: 10));
          break;
        case AudioManagerEvents.seekComplete:
          position = AudioManager.instance.position;
          slider.value  = position.inMilliseconds / duration.inMilliseconds;
          update();
          print("seek event is completed. position is [$args]/ms");
          break;
        case AudioManagerEvents.buffering:
          print("buffering $args");
          break;
        case AudioManagerEvents.playstatus:
          isPlaying.value  = AudioManager.instance.isPlaying;
          update();
          break;
        case AudioManagerEvents.timeupdate:
          position = AudioManager.instance.position;
          slider.value  = position.inMilliseconds / duration.inMilliseconds;
          update();
          AudioManager.instance.updateLrc(args["position"].toString());
          break;
        case AudioManagerEvents.error:
          error.value  = args;
          update();
          break;
        case AudioManagerEvents.ended:
          AudioManager.instance.next();
          break;
        case AudioManagerEvents.volumeChange:
          sliderVolume.value  = AudioManager.instance.volume;
          update();
          break;
        default:
          break;
      }
    });
  }

  void loadFile() async {
    // read bundle file to local path
    final audioFile = await rootBundle.load("assets/aLIEz.m4a");
    final audio = audioFile.buffer.asUint8List();

    final appDocDir = await getApplicationDocumentsDirectory();
    print(appDocDir);

    final file = File("${appDocDir.path}/aLIEz.m4a");
    file.writeAsBytesSync(audio);

    AudioInfo info = AudioInfo("file://${file.path}",
        title: "file", desc: "local file", coverUrl: "assets/aLIEz.jpg");

    list.add(info.toJson());
    AudioManager.instance.audioList.add(info);
    update();
  }

  Future<void> initPlatformState() async {
    String platformVersion;
    try {
      platformVersion = await AudioManager.instance.platformVersion;
    } on PlatformException {
      platformVersion = 'Failed to get platform version.';
    }
   /* if (!mounted) return;*/


      platformVersion = platformVersion;
    update();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void increment() => count.value++;
}
